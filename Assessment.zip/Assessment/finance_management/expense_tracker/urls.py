from django.contrib import admin
from django.urls import path,include

from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path("", views.login, name='login'),
    path('home', views.index, name="home"),
    path('add', views.add, name="add"),
    path('edit', views.edit, name="edit"),
    path('update/<str:id>', views.update, name="update"),
    path('delete<str:id>', views.delete, name="delete"),
    path('view_expenses', views.view_expenses, name="view_expenses"),
    # path("logout", views.logout, name='logout'),
]